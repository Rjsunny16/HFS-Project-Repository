import { LightningElement } from 'lwc';

export default class Wtl extends LightningElement {
    dateController : function(component, event, helper){
        var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
        var dateValue = component.get("v.objContact.Birthdate");
        console.log(today);
    
        if(dateValue > today){
            alert('You can not enter grater than today!');
            dateValue = null;
            component.set("v.objContact.Birthdate", dateValue);
        }
    }
}
